#!/bin/bash
kill $(cat pid.txt)
